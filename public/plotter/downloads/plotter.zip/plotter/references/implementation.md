# Website integration

Read when editing the standalone Plotter website, its React components, or a host integration. Portable composition, geometry, and motion instructions live in the [drawing](drawing.md), [animation](motion.md), and [foundation](foundation.md) references. This file is an optional host adapter; the installed skill does not depend on the website.

## Locate the host sources

Use the current checkout and read its `AGENTS.md`. Paths below are relative to the standalone repository root.

| Responsibility | Source |
| --- | --- |
| Canonical portable package | `skills/plotter/` |
| Shared token and geometry source | `skills/plotter/assets/foundation/` |
| Gallery SVG wrapper and role-style opt-in | `components/plotter/blueprint-drawing.tsx` |
| Editable catalogue SVGs | `components/plotter/drawings/` |
| Catalogue compiler and SVG serializer | `scripts/build-plotter-drawings.py`, `scripts/plotter_svg.py` |
| AG01 helper-fragment recipe | `skills/plotter/assets/examples/render-registration.mjs` |
| AG01 host file adapter | `scripts/build-plotter-registration.mjs` |
| Static W05 and O07 | `components/plotter/engineering-studies.tsx` |
| W05 shared core hatching | `components/plotter/production-chain-hatching.tsx` |
| W05 and O07 timelines | `components/plotter/production-chain-motion-drawing.tsx`, `components/plotter/newtons-cradle-motion-drawing.tsx` |
| Engineering playback, fallback, and visibility | `components/plotter/engineering-motion-preview.tsx` |
| Resolved pilot export adapter | `scripts/export-plotter-pilots.tsx` |
| Download artifact generator | `scripts/build-plotter-downloads.tsx` |
| Website documentation | `content/docs/` |

`BlueprintDrawing` opts into shared roles with `roles`. Token adoption currently covers **AG01 and W05**; legacy unmarked drawings keep their inherited stroke defaults. The SVG-to-JSX builder preserves supported root styles, removes standalone fixed ink and the root font family so the gallery inherits its theme and loaded font, and gives repeated definitions local IDs. Font weight, optical sizing, and GEOM settings remain authored. Standalone SVGs retain their own font stack.

Edit SVG sources and regenerate React output; catalogue and grammar components derived from those sources are generated artifacts. When the standard or AG01 source changes, use the repository-root sequence:

```sh
python3 skills/plotter/scripts/build-standard.py
node scripts/build-plotter-registration.mjs
python3 scripts/build-plotter-drawings.py
```

Refresh distributable downloads with:

```sh
bun scripts/build-plotter-downloads.tsx
```

Generation produces artifacts; visual correctness depends on inspecting the affected drawing within the requested scope.

## Preserve the integration boundary

The standalone website owns its layout. Its homepage introduces the drawing and animation workflows; `/proto` holds the design exploration. Keep study IDs stable and keep removed studies out of active metadata.

Present catalogue art at native `560 × 440` dimensions. Narrow containers may scroll locally. Preserve grammar isolation behavior: focused marks retain their original appearance, and supplemental grid segments restore only portions hidden with a form. Keep hover, keyboard, and touch access to that behavior.

Static drawings and animation timelines remain separate. W05’s static and animated core faces share a hatch component; its carrier frames remain unhatched. Playback owns pause/resume, replay, static fallback, reduced motion, and visibility. Timeline edits preserve the chosen still unless redesign is requested. Current source owns exact timing; [historical feedback](history/direction.md) explains particular revisions.

## Portable delivery from the website

From the repository root:

```sh
bun scripts/export-plotter-pilots.tsx /tmp/plotter-exports
```

This adapter renders the selected static W05 drawing and sends it, along with AG01, through the packaged exporter. Recipients need neither React nor Bun. General authoring uses the [portable examples](foundation.md#portable-examples) and Python exporter directly.

Resolved static SVG carries its appearance values and local definitions. Animated HTML carries its timeline, player, static fallback, and actual local resources, or inlines those resources for a single-file delivery. Neither format should rely on website imports.

## Historical coss integration

The original coss implementation lived under `apps/ui/app/plotter`, with the skill at `apps/ui/skills/plotter` and an unlinked `/ui/plotter` showcase. Its production hero selections and routes describe that earlier host. Preserve those details in [history](history/index.md); they are not active standalone repository paths.
