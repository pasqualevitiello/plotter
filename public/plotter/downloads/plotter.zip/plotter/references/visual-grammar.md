# Visual grammar

Start with the main form. For each supporting mark, name the relationship it explains. If removing the mark leaves that relationship equally clear, omit it. A drawing does not need every element below.

The linked **560 × 440** teaching SVGs are included in this package. Open the complete study for any mark you add or revise; no gallery or hover interaction is needed to understand it. Use the [drafting standard](drafting-standard.md#house-stroke-palette) and its shared token source for numerical treatment, and the [approved references](approved-references.md) for composition. Teaching examples do not expand that reference selection.

## Primary and secondary outlines

![The fragments and completed record read first.](grammar/outlines.svg)

Identity, name, and tools assemble into one record. Primary outlines hold the loose fragments and finished form together; quieter face details and construction lines support them. Keep supporting marks subordinate. Giving every stroke equal weight makes the construction compete with the subject.

An important loose fragment can remain primary even when small.


## Diagonal hatching

![One blade is selected; its boundaries and the central opening stay clear.](grammar/hatching.svg)

Hatching singles out one bounded region. Here it identifies a visible iris blade while the aperture remains clear. Its direction and spacing stay consistent across that region. Omit hatching when no region needs distinguishing. It is not a lighting effect or a material label.

A hatch describes a selected region or a stated cut, not generic lighting. A diagonal pattern alone does not identify a material. See [hatch grammar](drafting-standard.md#hatch-grammar).


## Background grids

![The grid reveals one module across the stem, counter, and bowl.](grammar/grids.svg)

A grid makes a shared construction module visible. This letter’s stem, counter, and bowl radii all follow the same 32-unit field. Omit a background grid when local guides already explain the relationship. Geometric subject matter alone is not a reason to add one.

Calendar cells can also be the subject itself, rather than a background construction field.


## Movement and transfer arrows

![The curved dashed shaft and solid open arrowhead show a quarter turn.](grammar/arrows.svg)

One rigid part turns around a shared pivot. The curved dashed shaft and solid open arrowhead show its movement from the current position to the proposed one. “Quarter turn” and its callout leader are separate annotations; they disappear during isolation. Use an arrow only when a change or direction matters; alignment and equal size need different marks.

Movement and conceptual transfer use the **transfer** role for the shaft with a solid open head. Alignment and size use projections or dimensions instead. A functional connector needs its own stated connectivity meaning.


## Callout leaders and labels

![The bent leader connects “Quarter turn” to the curved movement path.](grammar/callouts.svg)

A callout connects a short label to the feature it names. Here the bent solid leader anchors “Quarter turn” to the curved movement path. The leader and label form one annotation, and only those two elements remain during isolation.

Use a callout when a feature needs a name or explanation that its shape cannot supply. Omit labels that add no meaning. Keep the leader subordinate and end it on the named feature, with a clear gap before the text. Movement arrows convey direction; dimensions and radius leaders measure geometry. A callout supplies descriptive meaning.


## Projection guides

![Four quiet guides preserve the same two allocations.](grammar/projections.svg)

A whole task separates into two assigned scopes. Each projection connects the same width witness before and after separation, so the parts retain a visible relationship to the whole. Omit guides that cannot name both corresponding features. Nearby endpoints are not enough: the alignment must be exact.

Keep projections subordinate, stop them before labels and contours, and give each coincident segment one stroke owner.


## Dimensions and radius leaders

![One unit system connects the width, offset, and actual circular radius.](grammar/dimensions.svg)

Dimensions reveal the proportions that construct a form. Here a concentric bend keeps a constant offset, while its width and radius use the same unit. Omit measurements that do not explain the construction. Every witness and radius leader must reach the feature it measures.

Derive the label and its witnesses from the same geometry. A radius leader reaches the actual arc along its generating radius. See [geometry and dimensions](drafting-standard.md#geometry-and-dimensions).


## Centerlines and loci

![One center and one pitch circle locate all six repeated slots.](grammar/centerlines.svg)

Centerlines and a pitch circle reveal how repeated features share one center. Six curved slots follow the same circle at equal angular intervals. Omit axes and loci that do not explain symmetry, rotation, or placement. A dashed guide must pass through the geometry it claims to organize.

The **centerline** role identifies axes, centers, and theoretical pitch loci. A direct generating radius can instead use continuous secondary linework.


## Hidden, absent, and proposed outlines

![A dashed C-shaped boundary represents a channel concealed behind the plate’s front face.](grammar/states.svg)

The dashed C-shaped boundary represents a channel behind the plate’s visible front face. The channel exists, but this view cannot see it directly: this is **hidden geometry**. Only its dashed boundary remains during isolation. The solid line pointing to “Hidden rear channel” is a **callout leader** connecting a feature to explanatory text; both that leader and its label disappear on hover.

Hidden means present but concealed; absent means missing; proposed means a possible future form. Name the intended state rather than expecting the dash pattern alone to distinguish these meanings.

The **hidden**, **absent**, and **proposed** roles share one line pattern. Use a state label and, when useful, a separate movement arrow for a proposed form. If hidden and absent features coexist, label their states or separate the views.


The main form should still read without its supporting marks. If it does not, revisit the composition before adding drafting detail.

## Teaching isolation

The SVGs' `data-grammar-focus` attributes identify the marks named by each topic. A host may use them to hide unrelated elements while retaining the complete drawing. Preserve the selected element's original color, opacity, stroke width, and dash pattern. Include labels and leaders only when they belong to the topic; dimension values belong to their dimension. Where a grid shares a stroke with a form, supplemental segments restore the lattice only while that form is hidden. The website’s hover, keyboard, and touch controls are a host implementation, not part of the drawing/animation workflows.
